`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: me
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments: oi
// 
//////////////////////////////////////////////////////////////////////////////////


module alu(
    input [15:0] A,
    input [15:0] B,
    input [2:0] op,
    output reg [15:0] res,
    output zero
    );
    always @(*) begin
        case (op)
            3'b000: res = A + B;
            3'b001: res = A - B;
            3'b010: res = A | B;
            3'b011: res = A ^ B;
            3'b100: res = A & B;
            3'b101: res = B << A;
            default: res = 16'b0;
        endcase
    end
            
assign zero = (res==16'b0);
endmodule
