`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 10/17/2026 04:12:33 PM
// Design Name: 
// Module Name: ctrl
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module ctrl(
    input [3:0] opc,
    output reg [2:0] aluop,
    output reg regw
    );
    
always @(*) begin
    aluop = 3'b000;
    regw = 1'b0;
 
        case (opc)
            4'b0000: begin       //add
                aluop = 3'b000;
                regw = 1'b1;
            end
          
            4'b0001: begin       //sub
                aluop = 3'b001;
                regw = 1'b1;
            end
      
            4'b0010: begin       //and
                aluop = 3'b010;
                regw = 1'b1;
            end
   
            4'b0011: begin       //or
                aluop = 3'b011;
                regw = 1'b1;
            end
    
            4'b0100: begin       //xor
                aluop = 3'b100;
                regw = 1'b1;
            end
        endcase
    end
endmodule
