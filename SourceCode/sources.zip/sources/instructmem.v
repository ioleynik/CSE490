`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 10/17/2026 03:05:12 PM
// Design Name: 
// Module Name: instructmem
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module instructmem(
    input [7:0] addr,
    output [15:0] inst
    );
    reg [15:0] mem [0:255];
    
    initial begin
        //later, doesnt have any meaning rn
    end
endmodule
