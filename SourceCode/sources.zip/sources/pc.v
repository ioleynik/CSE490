`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 10/14/2026 03:54:58 PM
// Design Name: 
// Module Name: pc
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module pc(
    input clock,
    input reset,
    input [15:0] next,
    output reg [15:0] out
    );
    
    always @(posedge clock) begin
        if (reset)
            out<=16'b0;
            
        else
            out<=next;
    end
endmodule
