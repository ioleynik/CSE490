`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 10/18/2026 01:35:39 PM
// Design Name: 
// Module Name: cpu
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module cpu16(
    input clk,
    input reset
);

    wire [15:0] pc;
    wire [15:0] pc2;  
    wire [15:0] instr; 
    wire [3:0] opc;
    wire [3:0] rd; //both input and des
    wire [3:0] rs; 
    wire [15:0] rdata1; 
    wire [15:0] rdata2; 
    wire [2:0] aluop; 
    wire [3:0] funct; // bits 3:0 for func / imm   
    wire regw;  
          
    wire [15:0] res;
    wire zero;
         
    assign opc = instr[15:12]; //4 bits per
    assign rd = instr[11:8];
    assign rs = instr[7:4];
    assign funct = instr[3:0];
    
     
    assign pc2 = pc + 16'd2; //instructions r 2 bytes

   
    pc PCU (
        .clock(clk), 
        .reset(reset), 
        .next(pc2),
        .out(pc)
    );


    instructmem IMEMU (
        .addr(pc[7:0]),
        .inst(instr)
    );


    ctrl CTRLU (
        .opc(opc),
        .funct(funct),
        .aluop(aluop),
        .regw(regw)
    );
     
    register REGF (
        .clock(clk),
        .writeYN(regw),
        .rreg1(rs),
        .rreg2(rd),
        .wreg(rd),
        .wdata(res),
        .rdata1(rdata1),
        .rdata2(rdata2)
    );
 
  
    alu ALU (
        .A(rdata1),
        .B(rdata2),
        .op(aluop),
        .res(res),
        .zero(zero)
    );
  
endmodule
