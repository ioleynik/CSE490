`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 10/18/2026 01:35:39 PM
// Design Name: 
// Module Name: cpu
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module cpu16(
    input clk,
    input reset
);

    wire [15:0] pc;
    wire [15:0] pc2;  
    wire [15:0] instr; 
    wire [3:0] opc;
    wire [2:0] rd;
    wire [2:0] rs;  
    wire [2:0] rt; 
    wire [15:0] rdata1; 
    wire [15:0] rdata2; 
    wire [2:0] aluop; 
    wire regw;  
          
    wire [15:0] res;
    wire zero;
         
    assign opc = instr[15:12];
    assign rd = instr[11:9];
    assign rs = instr[8:6];
    assign rt = instr[5:3];
       
     
    assign pc2 = pc + 1;

   
    pc PCU (
        .clock(clk), 
        .reset(reset), 
        .next(pc2),
        .out(pc)
    );


    instructmem IMEMU (
        .addr(pc[7:0]),
        .inst(instr)
    );


    ctrl CTRLU (
        .opc(opc),
        .aluop(aluop),
        .regw(regw)
    );
     
    register REGF (
        .clock(clk),
        .writeYN(regw),
        .rreg1(rs),
        .rreg2(rt),
        .wreg(rd),
        .wdata(res),
        .rdata1(rdata1),
        .rdata2(rdata2)
    );
 
  
    alu ALU (
        .A(rdata1),
        .B(rdata2),
        .op(aluop),
        .res(res),
        .zero(zero)
    );
  
endmodule
