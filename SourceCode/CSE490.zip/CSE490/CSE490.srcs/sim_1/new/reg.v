`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 10/04/2026 07:16:30 PM
// Design Name: 
// Module Name: reg
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module reg(
    input [2:0] rreg1,
    input [2:0] rreg2,
    input [2:0] wreg,
    input [15:0] wdata,
    output [15:0] rdata1,
    output [15:0] rdata2
    );
endmodule
