`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 10/04/2026 07:16:30 PM
// Design Name: 
// Module Name: reg
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module register(
    input [2:0] rreg1,
    input [2:0] rreg2,
    input [2:0] wreg,
    input [15:0] wdata,
    input clock,
    output [15:0] rdata1,
    output [15:0] rdata2
    );
    reg [15:0] regs [0:7];
    assign rdata1 = regs[rreg1];
    assign rdata2 = regs[rreg2];
    
    always @(posedge clk) begin
        regs[wreg] <= wdata;
    end
endmodule
