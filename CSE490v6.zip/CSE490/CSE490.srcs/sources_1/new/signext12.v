`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 10/31/2026 08:15:49 PM
// Design Name: 
// Module Name: signext12
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module signextend12(
    input [11:0] value, 
    output [15:0] extended);  
    assign extended ={{4{value[11]}}, value};
endmodule
