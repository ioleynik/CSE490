`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Design Name: 
// Module Name: datamemory
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module datamemory(
    input clk,
    input wenable,
    input [15:0] addr,
    input [15:0] wdata,
    output [15:0] rdata
);  
    reg [7:0] mem [0:255];
    integer i;  
    initial begin 
        for (i = 0; i < 256; i = i + 1)
            mem[i] = 8'h00; 
    end 
    assign rdata = (addr < 16'd255)? {mem[addr], mem[addr + 16'd1]} : 16'b0;
    always @(posedge clk) begin  
        if (wenable && (addr < 16'd255)) begin 
            mem[addr]<= wdata[15:8];  
            mem[addr + 16'd1]<= wdata[7:0];  
        end  
    end  
endmodule
