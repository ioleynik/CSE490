`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 10/04/2026 07:16:30 PM
// Design Name: 
// Module Name: reg
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module register(
    input [3:0] rreg1, //wider selectors cz more now
    input [3:0] rreg2,
    input [3:0] wreg,
    input [15:0] wdata,
    input reset,
    input clock,
    input writeYN,
    output [15:0] rdata1,
    output [15:0] rdata2
    );
    reg [15:0] regs [0:15]; //needs to be 16 
    integer i;
    assign rdata1 = regs[rreg1];
    assign rdata2 = regs[rreg2];
    
    always @(posedge clock) begin
        if (reset) begin
            for(i = 0; i < 16; i = i+1)
            regs[i] <=16'b0;
        end else if (writeYN) begin
            regs[wreg] <= wdata;
        end
    end
endmodule
