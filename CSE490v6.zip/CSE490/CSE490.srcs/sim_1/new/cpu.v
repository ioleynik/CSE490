`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 10/18/2026 01:35:39 PM
// Design Name: 
// Module Name: cpu
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module cpu16(
    input clk,
    input reset,
    output [15:0] io_pc, //for board display
    output [15:0] io_curr_inst,
    output [15:0] io_alu_result
);

    wire [15:0] pc;
    wire [15:0] pc2;  
    wire [15:0] instr; 
    wire [3:0] opc;
    wire [3:0] rd; //both input and des
    wire [3:0] rs; 
    wire [15:0] rdata1; 
    wire [15:0] rdata2; 
    wire [2:0] aluop; 
    wire [3:0] funct; // bits 3:0 for func / imm   
    wire regw;  
          
    wire [15:0] res;
    wire zero;
    wire alusrc;
    wire memw;
    wire memtoreg;
    wire beq;
    wire bne;
    wire jump;

    wire [15:0] imm_ext; //exapnded to 16 bits from og imm
    wire [15:0] alu_b; //input b for alu
    wire [15:0] mem_data;
    wire [15:0] writeback_data;
    wire mem_write_enable;

    //branch/jump wires
    wire [15:0] jump_target;
    wire [15:0] branch_pc;
    wire [15:0] next_pc;
    wire [15:0] jump_ext;
    wire [15:0] branch_target;

    wire branch_taken;

    //beq takes branch when zero is 1 and bne takes it if 0
    assign branch_taken = (beq && zero) || (bne && !zero); 
    assign io_pc = pc;
    assign io_curr_inst  = instr;
    assign io_alu_result = res;
         
    assign opc = instr[15:12]; //4 bits per
    assign rd = instr[11:8];
    assign rs = instr[7:4];
    assign funct = instr[3:0];
    
    assign pc2 = pc + 16'd2; //instructions r 2 bytes
    assign branch_target = pc2 + (imm_ext << 1);
    assign jump_target = pc2 + (jump_ext << 1);
    assign mem_write_enable = memw && !reset; //stop stores

   
    pc PCU (
        .clock(clk), 
        .reset(reset), 
        .next(next_pc),
        .out(pc)
    );


    instructmem IMEMU (
        .addr(pc[7:0]),
        .inst(instr)
    );


    ctrl CTRLU (
        .opc(opc),
        .funct(funct),
        .aluop(aluop),
        .regw(regw),
        .alusrc(alusrc),
        .memw(memw),
        .memtoreg(memtoreg),
        .beq(beq),
        .bne(bne),
        .jump(jump)
    );
     
    signextend4 IMMEXTU (
        .value(instr[3:0]),
        .ext(imm_ext)
    );

    mux_16 ALUSRCMUX (
        .d0(rdata2),
        .d1(imm_ext),
        .sel(alusrc),
        .y(alu_b)
    );

    register REGF (
        .clock(clk),
        .reset(reset),
        .writeYN(regw),
        .rreg1(rs),
        .rreg2(rd),
        .wreg(rd),
        .wdata(writeback_data), //wordread vs adress writes from res
        .rdata1(rdata1),
        .rdata2(rdata2)
    );
 
  
    alu ALU (
        .A(rdata1),
        .B(alu_b), //should pass through mux vs fetchng from rdata2
        .op(aluop),
        .res(res),
        .zero(zero)
    );

    datamemory DMEMU (
        .clk(clk),
        .wenable(mem_write_enable),
        .addr(res),
        .wdata(rdata2),
        .rdata(mem_data)
    );

    mux_16 WBMUX ( 
        .d0(res),
        .d1(mem_data),
        .sel(memtoreg),  //if 0 then alu result if 1 then word read from mem
        .y(writeback_data)
    );

    signextend12 JUMPEXTU ( //cz default is sigend 12 bit
        .value(instr[11:0]),
        .extended(jump_ext)
    );

    mux_16 BRANCHMUX (
        //if branch not taken then normal pc + 2
        //if taken then to target
        .d0(pc2),
        .d1(branch_target),
        .sel(branch_taken),
        .y(branch_pc)
    );

    mux_16 JUMPMUX (
        //basicaly same as above but jump
        .d0(branch_pc),
        .d1(jump_target),
        .sel(jump),
        .y(next_pc)
    );
endmodule
