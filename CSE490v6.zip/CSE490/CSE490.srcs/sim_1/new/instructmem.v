`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 10/17/2026 03:05:12 PM
// Design Name: 
// Module Name: instructmem
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module instructmem(
    input [7:0] addr,
    output [15:0] inst
    );
    reg [7:0] mem [0:255];
    integer i;
    initial begin
        for (i = 0; i < 256; i = i + 1)
            mem[i] = 8'h00;
        //rn hex encodes to addi s1, s0, 5 and then jump to loop
        $readmemh("program.mem", mem);
    end
    
    assign inst = (addr < 16'd255)? {mem[addr], mem[addr + 16'd1]}: 16'h0000; 
endmodule
