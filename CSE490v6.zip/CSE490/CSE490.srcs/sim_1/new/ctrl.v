`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 10/17/2026 04:12:33 PM
// Design Name: 
// Module Name: ctrl
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module ctrl(
    input [3:0] opc,
    input [3:0] funct,
    output reg [2:0] aluop,
    output reg regw,
    output reg alusrc, 
    output reg memw,   
    output reg memtoreg, 
    output reg beq,      
    output reg bne,  
    output reg jump
);

    always @(*) begin
        aluop = 3'b000;
        regw = 1'b0;
        alusrc = 1'b0;
        memw = 1'b0;
        memtoreg = 1'b0;
        beq = 1'b0;
        bne = 1'b0;
        jump = 1'b0;

        if (opc == 4'b0000) begin
            case (funct)
                4'b0000: begin       //add
                    aluop = 3'b000;
                    regw = 1'b1;
                end

                4'b0001: begin       //sub
                    aluop = 3'b001;
                    regw = 1'b1;
                end

                4'b0010: begin       //sll
                    aluop = 3'b101;
                    regw = 1'b1;
                end

                4'b0011: begin       //and
                    aluop = 3'b100;
                    regw = 1'b1;
                end

                default: begin
                    aluop = 3'b000;
                    regw = 1'b0;
                end
            endcase
        end else if (opc == 4'b0001) begin //lw
            aluop = 3'b000; 
            alusrc = 1'b1; 
            memtoreg = 1'b1;
            regw = 1'b1;
        
        end else if (opc == 4'b0010) begin //sw
            aluop = 3'b000; 
            alusrc = 1'b1;
            memw = 1'b1; 
        
        end else if (opc == 4'b0011) begin //addi
            aluop = 3'b000; 
            alusrc = 1'b1;  
            regw = 1'b1; 
        
        end else if (opc == 4'b0100) begin //beq
            aluop = 3'b001;  
            beq = 1'b1;  
        
        end else if (opc == 4'b0101) begin //bne
            aluop = 3'b001;
            bne = 1'b1; 
        end else if (opc == 4'b0110) begin //jmp
            jump = 1'b1; 
        end
    end

endmodule